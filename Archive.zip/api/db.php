<?php
define('DB_HOST', 'sql208.infinityfree.com');
define('DB_USER', 'if0_41877438');
define('DB_PASS', 'ZyEY8xOZypra1gI');
define('DB_NAME', 'if0_41877438_tasktracker');

function getConnection(): mysqli {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['success' => false, 'error' => 'Koneksi database gagal: ' . $conn->connect_error]));
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}
